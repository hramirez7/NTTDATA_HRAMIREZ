package com.cliente.nttdatacliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NttdataclienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(NttdataclienteApplication.class, args);
	}

}


