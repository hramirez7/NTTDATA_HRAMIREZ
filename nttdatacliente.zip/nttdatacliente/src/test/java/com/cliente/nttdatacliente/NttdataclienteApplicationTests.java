package com.cliente.nttdatacliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NttdataclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
