package com.movimientos.nttdatamovimientos.service;

import com.movimientos.nttdatamovimientos.dto.CuentaRequest;
import com.movimientos.nttdatamovimientos.dto.CuentaResponse;

import java.util.List;

public interface CuentaService {
     CuentaResponse crearCuenta(CuentaRequest request);
    CuentaResponse actualizarCuenta(Long id, CuentaRequest request);
    void eliminarCuenta(Long id);
    CuentaResponse obtenerCuentaPorId(Long id); 
    List<CuentaResponse> listarCuentas();
}
