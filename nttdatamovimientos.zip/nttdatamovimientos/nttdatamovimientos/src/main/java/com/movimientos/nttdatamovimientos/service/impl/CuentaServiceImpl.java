package com.movimientos.nttdatamovimientos.service.impl;

import com.movimientos.nttdatamovimientos.dto.CuentaRequest;
import com.movimientos.nttdatamovimientos.dto.CuentaResponse;
import com.movimientos.nttdatamovimientos.exception.ResourceNotFoundException;
import com.movimientos.nttdatamovimientos.mapper.CuentaMapper;
import com.movimientos.nttdatamovimientos.model.Cuenta;
import com.movimientos.nttdatamovimientos.repository.CuentaRepository;
import com.movimientos.nttdatamovimientos.service.CuentaService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentaServiceImpl implements CuentaService {

    private final CuentaRepository cuentaRepository;

    public CuentaServiceImpl(CuentaRepository cuentaRepository) {
        this.cuentaRepository = cuentaRepository;
    }

    @Override
public CuentaResponse crearCuenta(CuentaRequest request) {
    try {
        Cuenta cuenta = CuentaMapper.toEntity(request);
        // Guardamos la cuenta en el repositorio
        Cuenta cuentaGuardada = cuentaRepository.save(cuenta);
        return CuentaMapper.toDto(cuentaGuardada);
    } catch (Exception e) {
        // Aquí lanzamos la excepción con el mensaje de error general
        throw new ResourceNotFoundException("Error general al crear la cuenta: " + e.getMessage());
    }
}


    @Override
    public CuentaResponse actualizarCuenta(Long id, CuentaRequest request) {
        Cuenta cuenta = cuentaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta no encontrada con id: " + id));
    
        cuenta.setNumeroCuenta(request.getNumeroCuenta());
    
        // Convertir String a enum
        Cuenta.TipoCuenta tipoCuenta = Cuenta.TipoCuenta.valueOf(request.getTipoCuenta().toUpperCase());
        cuenta.setTipoCuenta(tipoCuenta);
    
        cuenta.setSaldoInicial(request.getSaldoInicial());
        cuenta.setEstado(request.getEstado());
        cuenta.setClienteId(request.getClienteId());
    
        return CuentaMapper.toDto(cuentaRepository.save(cuenta));
    }
    
    @Override
    public void eliminarCuenta(Long id) {
        if (!cuentaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cuenta no encontrada con id: " + id);
        }
        cuentaRepository.deleteById(id);
    }

    @Override
    public CuentaResponse obtenerCuentaPorId(Long id) {
        Cuenta cuenta = cuentaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta no encontrada con id: " + id));
        return CuentaMapper.toDto(cuenta);
    }

    @Override
    public List<CuentaResponse> listarCuentas() {
        return cuentaRepository.findAll()
                .stream()
                .map(CuentaMapper::toDto)
                .collect(Collectors.toList());
    }
}
