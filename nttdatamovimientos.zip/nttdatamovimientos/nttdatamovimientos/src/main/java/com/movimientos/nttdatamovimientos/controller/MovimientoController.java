package com.movimientos.nttdatamovimientos.controller;

import com.movimientos.nttdatamovimientos.dto.MovimientoDTO;
import com.movimientos.nttdatamovimientos.dto.ReporteEstadoCuentaDTO;
import com.movimientos.nttdatamovimientos.model.Movimiento;
import com.movimientos.nttdatamovimientos.service.MovimientoService;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/movimientos")
public class MovimientoController {

    private final MovimientoService movimientoService;

    public MovimientoController(MovimientoService movimientoService) {
        this.movimientoService = movimientoService;
    }

    @PostMapping(name = "RegistrarMovimientos")
    public ResponseEntity<Movimiento> registrarMovimiento(@RequestBody MovimientoDTO movimientoDTO) {
        try {
            Movimiento movimiento = movimientoService.registrarMovimiento(movimientoDTO);
            return new ResponseEntity<>(movimiento, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(name = "generarReporteEstadoCuenta")
    public List<ReporteEstadoCuentaDTO> generarReporte(
            @RequestParam("desde") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam("hasta") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {

        return movimientoService.generarReporte(desde, hasta);
    }
}
