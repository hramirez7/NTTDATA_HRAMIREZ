package com.movimientos.nttdatamovimientos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NttdatamovimientosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NttdatamovimientosApplication.class, args);
	}

}
